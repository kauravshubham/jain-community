<?php
class Member extends CI_Controller{
    public function Fetch_Members_Json(){
        $result=$this->MemberModel->Fetch_Members_Json();
        if(!$this->session->userdata('family_head_data'))
        {
           $session_data= $this->session->userdata('family_head_data');
            // $result=array($result,"member_id"=>)
        }
        else{

        }
    }
}
?>