<!DOCTYPE html>
<html>
<head>
	<title>JSC</title>
	<link rel="stylesheet" type="text/css" href="https://bootswatch.com/4/flatly/bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <script
  src="https://code.jquery.com/jquery-3.3.1.js"
  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous"></script>
  <script src="<?php echo base_url(); ?>assets/js/dropdown.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/member.js"></script>
</head>
<body>
  <?php if($this->native_session->get_flashdata('Family_Created')):?>
  <?php echo "<p class='alert alert-info'>".$this->native_session->get_flashdata('Family_Created')."</p>";?>
  <?php endif; ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="<?php echo base_url(); ?>">JSC</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor02">
    <ul class="navbar-nav mr-auto">
    	<li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>">Home <span class="sr-only">(current)</span></a></li>
		<li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>about">About</a></li>
	 	<li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>posts">Blog</a></li>
		<li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>categories">Categories</a></li>
      </li>
	</ul>
	<ul class="navbar-nav navbar-right">
          <?php if(!$this->native_session->get('logged_in')) : ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>login">Login</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>register">Register</a></li>
          <?php endif; ?>
          <?php if($this->native_session->get('logged_in')) : ?>
            <li><a href="<?php echo base_url(); ?>posts/create">Create Post</a></li>
            <li><a href="<?php echo base_url(); ?>categories/create">Create Category</a></li>
            <li><a href="<?php echo base_url(); ?>users/logout">Logout</a></li>
          <?php endif; ?>
          </ul>
  </div>
</nav>
<div class="container">