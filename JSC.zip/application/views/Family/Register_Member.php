<?php echo form_open_multipart('/add_first_member'); ?>
<?php if($error && validation_errors()):?>
<div class="alert alert-dismissible alert-danger">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <?php echo validation_errors(); ?>
</div>
<?php endif;?>
<input type="hidden" name="error" value='TRUE'>
<center><h1 ><?= $title; ?></h1></center>
<div class="row">
    <hr width="100%">
    <div class="col-lg-3">
        <div class="form-group">
          <label for="membername" >Name of  Member </label>
          <input type="text" class="form-control" id="membername" name="member_name">
        </div>
        <div class="form-group">
           <label for="DOB" >Date of Birth</label>
           <input type="date" class="form-control" id="DOB" name="Birth_date">
        </div>
         </div>
    <div class='col-lg-3'>
        <div class="form-group">
            <label for="gender" >Gender </label><br>
            <input type="radio" value="Male" id="gender" name="member_gender">Male
            <input type="radio"  value="Female" id="gender" name="member_gender">Female 
        </div>
        <div class="form-group">
            <label for="mobile"  style='margin-top: 15px;'>Relation .</label>
            <select class="form-control" id="relation" name="member_relation"><option>-Select-</option></select>
        </div>
        </div>
    <div class="col-lg-3">
        <!-- <div class="form-group">
            <label for="relation_other">Relation To</label>
            <select class="form-control" id="relation_other" name="relation_other"><option>-Select-</option></select>
        </div> -->
        <div class="form-group">
            <label for="ocupation">Ocupation</label>
            <select class="form-control" id="ocupation" name="member_ocupation"><option>-Select-</option></select>
        </div>
        <div class="form-group">
            <label for="mobile">Mobile</label>
            <input class="form-control" id="mobile" name="member_mobile">
        </div>
     </div>
     <div class='col-lg-3'>       
        <div class="form-group">
            <label for="image" >Image</label>
            <input type="file" accept="jpg/jpeg/png" class="form-control" id="image" name="member_image">
        </div>
         <div class="form-group">
            <div id='gotra_f'></div>
        </div>
        <br>
        <button id='submit' type=submit class=" btn btn-success ">Submit</button>
    </div>
</div>
<?php echo form_close(); ?>