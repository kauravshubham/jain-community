<?php echo form_open_multipart('/register'); ?>
<?php
if(validation_errors()):?>
<div class="alert alert-dismissible alert-danger">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <?php echo validation_errors(); ?>
</div>
<?php endif;?>
<center><h1 ><?= $title; ?></h1></center>
<div class="row">
   
        <hr width="100%">
    <div class="col-lg-3">
        <div class="form-group">
            <label for="membername" >Name of  Family Head </label>
            <input type="text" class="form-control" id="membername" name="membername">
        </div>
        <div class="form-group">
           <label for="DOB" >Date of Birth</label>
           <input type="date" class="form-control" id="DOB" name="dob">
        </div>
        <div class="form-group">
            <label for="gender" >Gender </label><br>
            <input type="radio" value="Male" id="gender" name="gender">Male&nbsp;&nbsp;
            <input type="radio"  value="Female" id="gender" name="gender">Female 
        </div>
        <div class="form-group" style='margin-top: 32px;'>
           <label for="landmark" >Landmark</label>
           <input type="text" class="form-control" id="landmark" name="landmark">
        </div>
         </div>
        <div class="col-lg-3">
         <div class="form-group">
            <label for="state" >State</label>
            <select class="form-control" id="state" name="state"><option>-Select-</option></select>
         </div>
        
         <div class="form-group">
            <label for="city" >City</label>
            <select class="form-control" id="city" name="city"><option>-Select-</option></select>
         </div>
        
         <div class="form-group">
            <label for="ward" >Ward</label>
            <select class="form-control" id="ward" name="ward"><option>-Select-</option></select>
         </div>
         <div class="form-group">
            <label for="colony" >Colony </label>
            <select class="form-control" id="colony" name="colony"><option>-Select-<option></select>
         </div>
         </div>
        <div class='col-lg-3'>
         <div class="form-group">
            <label for="mobile" >Mobile No.</label>
            <input  type="text" class="form-control" id="mobile" name="mobile">
         </div>
        
         <div class="form-group">
            <label for="subcast" >Sub Cast</label>
            <select  class="form-control" id="subcast" name="subcast"><option>-Select</option></select>
         </div>
         <div class="form-group">
            <label for="membername" >Gotra </label>
            <select class="form-control" id="gotra" name="gotra"><option>-Select-</option></select>
         </div>
         <div class="form-group">
             <label for="ocupation" >Ocupation/Eduation</label>
             <select class="form-control" id="ocupation" name="ocupation"><option>-Select-</option></select>
         </div>
         </div>
         <div class='col-lg-3'>
         <div class="form-group">
            <label for="email" >Email</label>
            <input type="email" class="form-control" id="email" name="email">
         </div>
         
         
         <div class="form-group">
            <label for="image" >Image</label>
            <input type="file" accept="image/*"  class="form-control" id="image" name="image">
         </div>
         <div class="form-group">
            <label for="password" >Pasword</label>
            <input type="password" class="form-control" id="password" name="password">
         </div>
         <div class="form-group">
            <label for="conf_password" >Conform Password</label>
            <input type="password" class="form-control" id="conf_password" name="conf_password">
         </div>
            <button id='submit' type=submit class=" btn btn-success ">Next</button>
        </div>
    </div>
</div>
<?php echo form_close(); ?>