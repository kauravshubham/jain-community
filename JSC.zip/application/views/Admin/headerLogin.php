<!DOCTYPE html>
<html>
<head>
	<title>JSC</title>
	<link rel="stylesheet" type="text/css" href="https://bootswatch.com/4/flatly/bootstrap.min.css">
</head>
<body>
<div class="container">
	<?php if($this->native_session->get_flashdata('login_failed')):?>
  <?php echo "<p class='alert alert-danger'>".$this->native_session->get_flashdata('login_failed')."</p>";?>
  <?php endif; ?>
  <?php if($this->native_session->get_flashdata('login_success')):?>
  <?php echo "alert(<p class='alert alert-success'>".$this->native_session->get_flashdata('login_success')."</p>)";?>
  <?php endif; ?>
