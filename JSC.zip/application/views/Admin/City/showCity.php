<center><h1 ><?= $title; ?></h1></center>

<div class="row">
<button id="newCity" class="btn btn-info">New City</button>
<div class="col-lg-3">
      <select class="form-control" id="selected_state" name="state"><option>-Select State-</option></select>
</div>
<div id="new"></div>
</div>
<div id="result_city">
</div>