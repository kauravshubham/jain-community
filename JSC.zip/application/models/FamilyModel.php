<?php
class FamilyModel extends CI_Model
{
    function __construct()
	{
		$this->load->database();
    }
    public function newFamily($family_data,$member_data)
    {
        //insert record into member
        $this->db->insert('member',$member_data);
        //get last inserted member id
        $head_id=$this->db->insert_id();
        //merge head_id into family data
        $family_data=array_merge($family_data,array('head_id'=>$head_id));
        //insert record into family
        $this->db->insert('family',$family_data);
        //get last inserted family id
        $family_id=$this->db->insert_id();
        // add family_id into member
        $this->db->where('member_id', $head_id);
        $this->db->update('member', array('family_id'=>$family_id));
        $this->db->select("family_id,member_state,member_city,member_ward,member_colony,member_cast,member_subcast,member_gotra");
        $this->db->where("member.family_id",$family_id);
        $query=$this->db->get('member');
        
        return $query->row_array();
    }
}
?>